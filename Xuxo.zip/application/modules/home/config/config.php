<?php

$config['default-controller'] = 'index';
$config['default-action'] = NULL;
$config['default-layout'] = 'front';