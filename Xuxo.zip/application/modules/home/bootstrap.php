<?php
defined('BASEPATH') OR exit('No direct script access allowed');
defined('DIR_SEPARATOR') || define('DIR_SEPARATOR', '/');
defined('XUXO_VERSION') || define('XUXO_VERSION', '1.0.0');

class Home extends Xuxo_Bootstrap {
	
	public function __construct() {
		parent::__construct();
		
	}
	
	public function preInitController() {
		
	}
	
	public function postInitController() {
		
	}
	
	public function preInitAction() {
		
	}
	
	public function postInitAction() {
		
	}
	
}
