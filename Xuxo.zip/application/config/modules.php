<?php

/**
* MODULES CONFIGURATION
*/
$modules['home'] = 'application/modules/home';
