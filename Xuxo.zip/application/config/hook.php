<?php

$hook['precall'] = function() {
};

$hook['postcall'] = function() {
};

$hook['prerender'] = function() {
};

$hook['postrender'] = function() {
};

?>
