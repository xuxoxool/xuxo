<?php

/**
* AUTOLOAD CONFIGURATION
*/
$autoload['libraries'] = array('session','auth','layouts','flashdata');
$autoload['language'] = array();
$autoload['model'] = array();
$autoload['helpers'] = array();
