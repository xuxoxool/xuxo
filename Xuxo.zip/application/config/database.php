<?php
$db['default']['type'] = 'MYSQL';
$db['default']['name'] = 	'mydb';
$db['default']['host'] = 'localhost';
$db['default']['port'] = '3306';
$db['default']['user'] = 'root';
$db['default']['pass'] = '';
$db['default']['connect-on-init'] = TRUE;

