<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR: [2017-08-23 17:35:44] --> Module '' does not exist in configuration, will call default module if set.
ERROR: [2017-08-23 17:35:50] --> Module '' does not exist in configuration, will call default module if set.
ERROR: [2017-08-23 17:36:05] --> Module '' does not exist in configuration, will call default module if set.
